# XNP GR 0.7.7 Test Plan

Startup:
1. Pack this SOURCE manually with Valve vpk.exe.
2. Enable only this VPK.
3. Confirm `[XNP ATS ENTRY]`, `[XNP ATS CORE TOP]`, and `[XNP ATS BUILD]`.

Manual tongue escape:
1. Equip melee and stand normally.
2. Let a Smoker tongue grab the player.
3. Do not press Shift: confirm no automatic manual escape.
4. Repeat and press Shift once: confirm controlling Smoker dies.
5. Confirm player is released and charge drops by exactly 1.
6. Confirm no extra health cost.
7. Confirm aftershock runs.
8. Confirm nearby non-controlling Smokers are not killed.
9. Spam Shift: confirm only one charge and one kill per grab token.
10. Hold Shift after escape, then release: confirm no Ground Normal Dash is appended.
11. With 0 charge, confirm no free escape.
12. Press Shift within 0.25 seconds before grab: confirm one escape can happen.
13. Hold Shift long before grab: confirm it waits for release and fresh press.

Regression:
1. GROUND_HOLD still works without tongue grab.
2. Ground Normal Dash still works.
3. Ground Attack Dash still works.
4. Air Normal Dash still works.
5. Air Attack Dash and triple slash still work.
6. Existing protected-state automatic breakout still works without extra charge.
7. Tank Stagger, stun, knockback and FX remain unchanged from the previous validated behavior.
8. Charge HUD and recharge remain unchanged.
