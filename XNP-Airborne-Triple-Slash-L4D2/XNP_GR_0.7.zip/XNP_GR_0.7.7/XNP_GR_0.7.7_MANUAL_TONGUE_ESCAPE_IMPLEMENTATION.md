# XNP GR 0.7.7 Manual Tongue Escape Implementation

Baseline: previous validated SOURCE.

Implemented:
- Added per-player tongue control token fields.
- `tongue_grab` and `choke_start` now arm a manual tongue escape token for the actual victim and controlling Smoker.
- Added `TryManualTongueEscapeFromSkillInput`.
- The manual path spends exactly 1 skill charge, costs 0 health, kills only the controlling Smoker, starts the existing aftershock, applies the existing short regrab protection, and clears the token.
- The path does not create dash nonce, ground dash, air dash, air session, Combo progress, TEMP reward, special hit charge restore, or player velocity.

Input:
- Fresh Shift press while a token is armed has priority before `GROUND_HOLD`.
- A Shift press up to 0.25 seconds before the tongue grab can be accepted once.
- Long-held Shift older than the buffer only arms the token and waits for a fresh press.

Failure handling:
- No charge: reject once per token with `reason=no_charge`.
- No melee: reject once per token with `reason=no_melee`.
- Invalid or dead Smoker: clear the token without spending charge.
- If charge is consumed but the Smoker kill path fails, 1 charge is refunded.
