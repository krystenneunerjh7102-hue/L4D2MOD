# XNP GR 0.7.7 Tongue Input Priority Audit

Required priority:
1. Manual tongue escape.
2. Existing protected-state automatic breakout.
3. `GROUND_HOLD`.
4. `AIR_HOLD`.
5. Normal Dash input.

Source audit:
- `ProcessPlayer` registers the fresh Shift edge.
- If `state.tongue_escape_armed` is true, `TryManualTongueEscapeFromSkillInput` runs and the frame returns before ground or air skill entry.
- Successful manual escape sets `suppress_skill_until_release_after_tongue_escape`.
- While Shift remains held, the suppress flag prevents entering `GROUND_HOLD` or `AIR_HOLD`.
- The suppress flag clears only on Shift release.

Expected behavior:
- Shift while controlled by Smoker triggers manual escape first.
- The same Shift hold cannot later release into Ground Normal Dash.
- Without an armed token, normal previous-baseline ground input behavior remains.
