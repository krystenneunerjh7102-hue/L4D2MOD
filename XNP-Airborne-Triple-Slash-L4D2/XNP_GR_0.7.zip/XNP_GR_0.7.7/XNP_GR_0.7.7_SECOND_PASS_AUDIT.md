# XNP GR 0.7.7 Second Pass Audit

Reverse checks:
- All `tongue_grab` and `choke_start` paths go through `HandleSmokerBreakoutGrab`.
- Manual path and automatic protected-state path share `ConsumeTongueEscapeToken`.
- Manual path consumes charge only through `ConsumeManualTongueEscapeCharge`.
- Manual path starts aftershock only after the controlling Smoker kill succeeds.
- Manual path sets suppress until Shift release.
- `tongue_release` clears unconsumed tokens.
- `player_death`, incapacitation, round reset and map reset clear token state.
- Smoker death clears victim tokens pointing at that Smoker.

Regression checks:
- No Tank functions were intentionally changed.
- Ground Dash entry remains available when no tongue token is active.
- Triple slash and charge system entry points were not redesigned.

Static checks are summarized in the final response.
