# XNP GR 0.7.7 Public Release String Audit

Public identity:
- Addon title: XNP Airborne Triple Slash 0.7.7 Tongue Escape.
- Version: 0.7.7-tongue-escape-public-release.
- Runtime notice: `[XNP Airborne Triple Slash 0.7.7] PUBLIC RELEASE`.
- Balance notice uses XNP Airborne Triple Slash / XNP空中三段斩 wording.

Cleaned:
- Player-facing README no longer uses Ghostrunner as the product name.
- Runtime entry/core/build logs use the `XNP ATS` prefix.
- Candidate-release wording was removed from runtime files.

Intentionally retained:
- Internal script filename `xnp_ghostrunner_execution_branch.nut`.
- Internal EMS directory `xnp_ghostrunner_execution_branch`.
- Internal root table names containing `Ghostrunner`, because renaming them increases load risk and they are not player-facing branding.
