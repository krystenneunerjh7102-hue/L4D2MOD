# XNP GR 0.7.7 Ground Dash Regression Audit

Frozen from the previous validated baseline:
- `GROUND_HOLD`
- Ground Normal Dash
- Ground Attack Dash
- ground area pulse
- ground common push
- ground special/Tank/Witch handling
- Ground Hold promotion to `AIR_HOLD`
- once-per-skill-hold
- no second/third slash from ground dash

0.7.7 change:
- A tongue escape token check now runs before ground skill entry.
- If there is no active token, the previous-baseline ground entry path is unchanged.
- If manual escape succeeds, the suppress flag prevents a later Shift release from triggering Ground Normal Dash.

No ground dash parameters were changed.
