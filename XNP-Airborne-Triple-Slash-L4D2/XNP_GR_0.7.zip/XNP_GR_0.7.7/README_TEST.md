XNP Airborne Triple Slash 0.7.7 Tongue Escape

User-pack workflow:
- Codex only prepares this SOURCE folder.
- User packs this folder manually with Valve vpk.exe.
- Do not enable this together with older XNP_GR local test VPKs.

Focus of 0.7.7:
- Public release identity for XNP Airborne Triple Slash.
- Active Smoker tongue escape: when controlled by a real Smoker, press Shift once to spend 1 charge and kill only the controlling Smoker.
- Existing automatic breakout remains for protected skill states.
- Existing Ground Hold, Ground Normal Dash, Ground Attack Dash, Air Triple Slash, Charge HUD, Fall Shield, Tank control and FX remain frozen.

Manual pack command:
& 'D:\gpd\steamapps\common\Left 4 Dead 2\bin\vpk.exe' 'C:\Users\Administrator.DESKTOP-O0ONJ61\Documents\Codex\2026-06-10\z-lavis-ai-exe-l4d2-workshop\XNP_GR_0.7.7'

Runtime identity logs:
- [XNP ATS ENTRY] 0.7.7 director
- [XNP ATS CORE TOP] version=0.7.7-tongue-escape-public-release
- [XNP ATS BUILD] GR_077_TONGUE_ESCAPE_PUBLIC_RELEASE_A

Key manual escape logs:
- [XNP ATS ESCAPE] tongue_control_armed victim=<ent> smoker=<ent> token=<token>
- [XNP ATS ESCAPE] manual_skill_press victim=<ent> smoker=<ent> token=<token>
- [XNP ATS ESCAPE] charge_consumed victim=<ent> before=<n> after=<n>
- [XNP ATS ESCAPE] controlling_smoker_killed victim=<ent> smoker=<ent> token=<token>
- [XNP ATS ESCAPE] manual_escape_completed victim=<ent> token=<token>

Negative checks:
- No Shift press: no automatic manual escape.
- Long-held Shift before tongue grab: no automatic escape; release and press again.
- Shift press within 0.25 seconds before tongue grab can be accepted once.
- 0 charge: no escape, no Smoker kill, no Ground Hold.
- Manual escape does not create Dash nonce, Ground Dash, Air Dash, Combo, TEMP reward or charge refund reward.
- Releasing Shift after successful escape must not trigger Ground Normal Dash.
- Existing skill-state automatic breakout must not spend an extra charge.

New configuration keys:
- tongue_manual_escape_enabled = true
- tongue_manual_escape_requires_melee = true
- tongue_manual_escape_requires_charge = true
- tongue_manual_escape_charge_cost = 1
- tongue_manual_escape_health_cost = 0
- tongue_manual_escape_once_per_grab = true
- tongue_manual_escape_recent_press_buffer = 0.25
- tongue_manual_escape_aftershock_enabled = true
- tongue_manual_escape_regrab_protection_enabled = true
