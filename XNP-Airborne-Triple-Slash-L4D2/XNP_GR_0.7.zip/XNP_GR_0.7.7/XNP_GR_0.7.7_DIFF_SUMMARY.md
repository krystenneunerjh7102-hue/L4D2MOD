# XNP GR 0.7.7 Diff Summary

Changed files:
- `addoninfo.txt`
- `README_TEST.md`
- `scripts/vscripts/director_base_addon.nut`
- `scripts/vscripts/xnp_ghostrunner_execution_branch.nut`
- `ems/xnp_ghostrunner_execution_branch/settings.cfg`
- `ems/xnp_ghostrunner_execution_branch/settings.normal.cfg`

Added:
- Manual tongue escape token state.
- Manual escape charge consume/refund helpers.
- Shared tongue escape token consume helper.
- Recent Shift press buffer.
- Suppress-until-release after successful manual escape.
- Public release identity and player-facing name cleanup.

Not added:
- No new dash damage path.
- No new Tank logic.
- No new HUD, VTF, VMT, overlay or particle assets.
- No VPK generation.

Frozen:
- Ground Dash system.
- Air triple slash.
- Charge HUD and recharge.
- Tank system.
- Fall Shield and existing protected-state breakout.
