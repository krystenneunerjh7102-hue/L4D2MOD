# XNP GR 0.7.7 Grab Token Dedup Audit

Token fields:
- `tongue_escape_armed`
- `tongue_escape_token`
- `tongue_escape_smoker_userid`
- `tongue_escape_smoker_entindex`
- `tongue_escape_grabbed_at`
- `tongue_escape_consumed`
- `tongue_escape_waiting_for_fresh_press`
- `tongue_escape_duplicate_logged`

Dedup rules:
- `ArmTongueEscapeControl` creates one token for the current controlling Smoker.
- `ConsumeTongueEscapeToken` marks a token consumed before manual or automatic completion.
- Existing protected-state automatic breakout consumes the same token.
- Manual escape consumes the same token.
- `choke_start` cannot silently replace an already armed token from the same Smoker.

Cleanup:
- `tongue_release` clears unconsumed tokens.
- victim death/incap/reset clears the victim state.
- Smoker death clears any victim token pointing at that Smoker.
- round/map/disconnect reset clears state through existing reset paths.
