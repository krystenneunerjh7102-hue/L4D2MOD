# XNP GR 0.7.7 Tank Freeze Regression Audit

Tank system is frozen in 0.7.7.

No changes were made to:
- Tank Stagger.
- Tank attack lock.
- Tank movement scale.
- Tank stun duration.
- Tank enforcement.
- Tank restore.
- Tank knockback.
- Tank velocity grace.
- Tank FX, spark, sound, light.
- Tank verification logic.
- Tank configuration values.

Manual tongue escape only uses existing Smoker breakout aftershock after the controlling Smoker is killed. It does not modify Tank logic.
